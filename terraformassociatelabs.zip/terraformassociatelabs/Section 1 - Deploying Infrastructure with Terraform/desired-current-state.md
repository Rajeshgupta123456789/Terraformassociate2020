
### Desired and Current State

i) Desired State: EC2 = instance_type = "t2.micro"

ii) Current State: EC2 = "instance_state": "stopped" && "instance_type" = "t2.nano"

Desired State == Current State
